extends Node

var zoom_mais = false
var zoom_menos = false

var em_movimento = false
