extends Node

var obj_interessante = false
var m1_alvo = null
var m2_mao = null

var camera_1 = null
