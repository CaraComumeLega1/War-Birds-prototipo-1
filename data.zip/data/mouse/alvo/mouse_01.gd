extends Position2D

func _ready():
	mouse_global.m1_alvo = self

func _input(event):
	if event is InputEventMouseButton and event.button_index == BUTTON_LEFT and event.pressed:
		self.global_position = event.global_position
