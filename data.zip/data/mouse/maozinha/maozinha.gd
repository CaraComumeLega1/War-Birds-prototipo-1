extends KinematicBody2D

onready var texturizando = $texturas
var clique_direito = false
var clique_esquerdo = false

func _ready():
	mouse_global.m2_mao = self
	texturizando.frames.set_animation_loop("clicando", false)
	texturizando.frames.set_animation_loop("pegando", false)

func movimentacao():
	self.global_position = get_global_mouse_position()
	
func controles():
	clique_esquerdo = Input.is_action_pressed("bm_esquerdo")
	clique_direito = Input.is_action_pressed("bm_direito")
	
func animacao():
	if not clique_esquerdo == true:
		texturizando.play("peg_parado")
	if clique_esquerdo == true:
		texturizando.play("pegando")
		
func _process(_delta):
	animacao()
	controles()
	
func _physics_process(_delta):
	movimentacao()
