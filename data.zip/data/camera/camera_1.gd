extends Camera2D

var velocidade = 20
var mover = false
var rapidinho = mouse_global.m2_mao

#variavies_das_bordas
onready var bordas_mov = $bordas
onready var b1_norte = $bordas/norte
onready var b2_sul = $bordas/sul
onready var b3_oeste = $bordas/oeste
onready var b4_leste = $bordas/leste

func _ready():
	mouse_global.camera_1 = self
		
func mover_camera():
	var corpo_norte = b1_norte.get_overlapping_bodies()
	var corpo_sul = b2_sul.get_overlapping_bodies()
	var corpo_oeste = b3_oeste.get_overlapping_bodies()
	var corpo_leste = b4_leste.get_overlapping_bodies()
	
	for body in corpo_norte:
		if body.is_in_group("maozinha"):
			self.global_position.y -= velocidade
			
	for body in corpo_sul:
		if body.is_in_group("maozinha"):
			self.global_position.y += velocidade
			
	for body in corpo_oeste:
		if body.is_in_group("maozinha"):
			self.global_position.x -= velocidade
			
	for body in corpo_leste:
		if body.is_in_group("maozinha"):
			self.global_position.x += velocidade
		
func dando_zoom():
	if Input.is_action_pressed("b_mais"):
		variavel_global.zoom_mais = true
	else:
		variavel_global.zoom_mais = false
		
	if Input.is_action_pressed("b_menos"):
		variavel_global.zoom_menos = true
	else:
		variavel_global.zoom_menos = false
		
	
	if variavel_global.zoom_mais == true:
		bordas_mov.scale.x += 0.1
		bordas_mov.scale.y += 0.1
		velocidade += 2
		self.zoom.x += 0.1
		self.zoom.y += 0.1
	if variavel_global.zoom_menos == true:
		if not bordas_mov.scale.x < 0.6:
			bordas_mov.scale.x -= 0.1
		if not bordas_mov.scale.y < 0.6:
			bordas_mov.scale.y -= 0.1
		if not velocidade < 22:
			velocidade -= 2
		if not self.zoom.x < 0.6:
			self.zoom.x -= 0.1
		if not self.zoom.y < 0.6:
			self.zoom.y -= 0.1
		
		
func _process(_delta):
	dando_zoom()
	mover_camera()
